import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-conferencia',
  templateUrl: './conferencia.component.html',
  styleUrls: ['./conferencia.component.css']
})
export class ConferenciaComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
